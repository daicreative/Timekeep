package com.dai.timekeep;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.NumberPicker;
import android.widget.TimePicker;

import java.sql.Time;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;
import android.content.SharedPreferences;


public class SleepActivity extends AppCompatActivity {

    private TimePicker tp;
    private Integer hour;
    private Integer minute;
    private SharedPreferences sharedPreferences;

    private TimePicker.OnTimeChangedListener tpListener = new TimePicker.OnTimeChangedListener() {
        @Override
        public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
            SleepActivity.this.minute = minute;
            SleepActivity.this.hour = hourOfDay;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.fadein, R.anim.fadeout);
        setContentView(R.layout.activity_sleep);
        tp = findViewById(R.id.sleepPicker);
        sharedPreferences = getSharedPreferences(getString(R.string.sharedPrefs), MODE_PRIVATE);
        setupPicker();
    }

    private void setupPicker() {
        hour = sharedPreferences.getInt( getString(R.string.sleepHour), 0);
        minute = sharedPreferences.getInt( getString(R.string.sleepMinute), 0);
        tp.setIs24HourView(true);
        tp.setHour(hour);
        tp.setMinute(minute);
    }

    public void divide(View view) {
        Date now = new Date();
        int nowMinutes = now.getHours() * 60 + now.getMinutes();
        int thenMinutes = hour * 60 + minute;
        int duration = (24*60 + thenMinutes - nowMinutes)%(24*60);
        if(sharedPreferences.contains(getString(R.string.calendarKey))){
            //subtract based on calendar
            //add points to switch based on calendar
            //duration += 2;
        }
        Intent i1 = new Intent(this, TaskActivity.class);
        i1.putExtra(getString(R.string.taskBoolean), true);
        i1.putExtra(getString(R.string.taskSleepLength), duration);
        startActivity(i1);
    }

}
