package com.dai.timekeep;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class TaskActivity extends AppCompatActivity {

    private boolean _configuring;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task);
        _configuring = getIntent().getExtras().getBoolean(getString(R.string.taskBoolean));
    }

    public void select(View view) {
        if(_configuring){
            Intent i1 = new Intent(this, AllocateActivity.class);
            i1.putExtras(getIntent());
            startActivity(i1);
        }
    }
}
