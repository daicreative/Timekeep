package com.dai.timekeep;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class OrderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
    }

    public void finish(View view) {
        Intent i1 = new Intent(this, ProgressActivity.class);
        //start up notifications
        i1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i1);
    }
}
